#ifndef __WS2812_H__
#define __WS2812_H__


void ws2812_init();
void ws2812_write(uint32_t i, char*);
//void ws2812_write(uint32_t i, char r, char g, char b);

#endif 

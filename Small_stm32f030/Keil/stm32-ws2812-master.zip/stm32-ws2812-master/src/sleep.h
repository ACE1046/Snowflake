#ifndef __SLEEP_H__
#define __SLEEP_H__

void usleep(uint32_t us);
void msleep(uint32_t msec);
void sleep(uint32_t sec);

#endif
